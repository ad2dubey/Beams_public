#include "retina4sn_viewer/data_handler.hpp"
#include <ostream>
#include <cmath>
#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>


#define PORT 8080


int DataHandler::check(){


 //  int sum = r_data[0].x + r_data[0].y +r_data[0].z ;
 //  ROS_WARN("sum  : %d", sum);
   
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
    //char buffer[1024] = {0};
    //const char* hello = "Hello from C++";
   // int sd= sizeof(r_data);
    //std::array<POINT_DATA, MAX_NUM_POINTS_PER_FRAME>* sd1= &r_data;
    //std::array POINT_DATA* sd1 = r_data;
    //ROS_WARN("size of sd: %d", sd);
    
    // Create socket object
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }
    
    // Define server address
    serv_addr.sin_family = AF_INET; // IPv4
    serv_addr.sin_port = htons(PORT); // convert port nuber to network connunication standard of big-endian
    
    // Convert IPv4 and IPv6 addresses from text to binary form and store in sin_addr of the serv_addr struct
    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address/ Address not supported\n";
        return -1;
    }
    
    // Connect to server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }
    
    // Send data through socket
    // send(sock , hello , strlen(hello) , 0 );
    //send(sock , (char*) &my_data , (sizeof(my_data) * my_data.size()), 0 );

    size_t vector_size = my_data.size();
    send(sock , &vector_size , sizeof(vector_size), 0 ); //sending the length of the vector

    send(sock ,my_data.data() , vector_size * sizeof(my_str), 0 );


    std::cout << "Data sent from C++\n";
    std::cout << sizeof(my_data) << " ";
    std::cout << "at test" << my_data.size();




   /*
    // Receive data from server
    if ((valread = read(sock, buffer, 1024)) < 0) {
        std::cerr << "Read failed\n";
        return -1;
    }

    // Print received data
    std::cout << "Received message: " << buffer << std::endl;

    */
    
  return 0;


}
