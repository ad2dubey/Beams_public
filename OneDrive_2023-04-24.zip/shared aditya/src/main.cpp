
#include "retina4sn_viewer/socket.hpp"
#include "retina4sn_viewer/data_handler.hpp"
#include <iostream>

int main(int argc, char **argv)
{
    int numTry = 0;
    Socket m_socket;
    std::string ip_addr;

    ros::init(argc, argv, "retina4sn_node");
    ros::NodeHandle nh; // Node Handler

    if (!(nh.getParam("/retina4sn_node/ip_addr", ip_addr)))
    {
        ROS_ERROR("failed to get IP address");
        return false;
    }
    else
    {
        ROS_INFO("IP Address : %s", ip_addr.c_str());
        std::cout << "this is my handle: " << ip_addr.c_str() << std::endl;
    }

    while (!m_socket.connectSocket(ip_addr.c_str(), RADAR_DATA_RX_PORT))
    {
        numTry++;
        if (numTry <= 20)
        { // 20 tries
            usleep(100000);
        }
        else
        {
            ROS_ERROR("Tried 20 times, but couldn't connect. Bye !");
            return 0;
        }
    }
    ROS_INFO("Connection  succeeded !");

    std::string output_file;
    // std::string output_file2;
    // ROS_INFO("Output file: %s", output_file.c_str());
    if (!(nh.getParam("/retina4sn_node/output_file", output_file)))
    {
        ROS_ERROR("failed to get output file");
        return false;
    }
    else
    {
        ROS_INFO("Output file: %s", output_file.c_str());
        std::cout << "this is my spout: " << output_file.c_str() << std::endl;
    }

    ros::Rate loop(100);

    DataHandler handler(nh, output_file);

    // Initialize the radar packet data handler
    handler.init();

    while (ros::ok())
    {
        // 1
        if (!handler.receive(m_socket, 1))
        {
            ROS_ERROR("failed to receive the packet data !!!");
            continue;
        }

        if (!handler.publish())
        {
            ROS_ERROR("failed to publish the points to RVIZ");
        }
    }

    return 0;
}
