#include "retina4sn_viewer/data_handler.hpp"
#include <ostream>
#include <cmath>



DataHandler::DataHandler(ros::NodeHandle &nh)
{
    handle = nh;
    offset_enable = false;
}

DataHandler::DataHandler(ros::NodeHandle &nh, const std::string & fileName)
{
    handle = nh;
    fileOut.open(fileName, std::ofstream::out);
    offset_enable = false;
}

DataHandler::~DataHandler()
{
    fileOut.close();
}

void DataHandler::init()
{
	// Point cloud publisher
	pub_points = handle.advertise<pcl::PointCloud<pcl::PointXYZINormal>> ("point_cloud", 1);

    // Set the basic properties of pointcloud 
    radarPoint.header.frame_id = "retina_link";
    radarPoint.height = 1; 
    radarPoint.width = 0;
    radarPoint.points.reserve(MAX_NUM_POINTS_PER_FRAME);

    // Set simulation time
    simulation_start = ros::Time::now();
}

void DataHandler::setFileOutput(const std::string & fileName)
{
    std::cout<<"the filename is " << fileName <<std::endl;
    fileOut.open(fileName, std::ofstream::out);
}

int8_t DataHandler::receive(Socket &sock, int radar_num)
{
    PACKET_BUFFER packetBuffer;
	int readBytes = 0;
	
    readBytes = sock.readData((uint8_t *)&packetBuffer.cmdHeader, RADAR_CMD_HEADER_LENGTH, true);
    
    if(readBytes == RADAR_CMD_HEADER_LENGTH) {
        if(memcmp(&packetBuffer.cmdHeader.header, NETWORK_TX_HEADER, NETWORK_TX_HEADER_LENGTH) != 0) {
            ROS_ERROR("Not match with the TI header magic number !!!");
            return 0;
        }

        if(packetBuffer.cmdHeader.dataSize > MAX_BUF_SIZE) {
            ROS_ERROR("Greater than max buffer size !");
            return 0;
        }
    } else {
        ROS_DEBUG("Read bytes(%d) is not matching the data size !!!", readBytes);
		return 0;
    }

    readBytes = sock.readData((uint8_t *)&packetBuffer.buf, FRAME_SIZE, true);
    ROS_WARN("packetlength: %d", readBytes);//added
    ROS_WARN("FRAME_SIZE: %d", FRAME_SIZE);

    if (readBytes == FRAME_SIZE)
    {
        if(memcmp(packetBuffer.pkHeader.magicWord, radarMagicWord, RADAR_OUTPUT_MAGIC_WORD_LENGTH) != 0)
        {
            ROS_DEBUG("Magic Word is not matched !!!");
            return 0;
        }

        ros::Duration elapsed_time = ros::Time::now() - simulation_start;

        //ros::Duration::Duration time = elapsed_time;

        ROS_WARN("Frame Counter : %f", time);

        // Frame Number
        frame_number = packetBuffer.pkHeader.frame_counter;
		ROS_WARN("Frame Counter : %d", frame_number);
			
        // The number of points
        nPoints = packetBuffer.pkHeader.targetNumber;
		ROS_WARN("Total number of points : %d", nPoints);

  

        for (uint32_t i = 0; i < nPoints; i++)
        {

            my_str temp;
            
            POINT_DATA *point = (POINT_DATA *)(packetBuffer.data + (sizeof(POINT_DATA) * i));

            if (offset_enable)
            {
                std::array<float, 3> temp_point = {point->x, point->y, point->z};
                temp_point = offsetFeed(temp_point);
                point->x = temp_point[0];
                point->y = temp_point[1];
                point->z = temp_point[2];
            }
            
            /*

            my_data[i].f_num = frame_number;
             my_data[i].pt_num = i;
            r_data[i] = *point;
             //my_data[i].x=
            my_data[i].x = r_data[i].x; 
            my_data[i].y = r_data[i].y; 
            my_data[i].z = r_data[i].z;
            my_data[i].power = r_data[i].power;
            my_data[i].doppler=r_data[i].doppler;

            
            */

            r_data[i] = *point;

            if(r_data[i].doppler != 0) { // Only add data if non-zero Doppler
                temp.f_num = frame_number;
                temp.pt_num = i;
                
                temp.x = r_data[i].x; 
                temp.y = r_data[i].y; 
                temp.z = r_data[i].z;
                temp.power = r_data[i].power;
                temp.doppler=r_data[i].doppler;
                
                my_data.push_back(temp);
            }
            


            // just for debugging
            ROS_DEBUG("[%d] (%.4f, %.4f, %.4f)", i, point->x, point->y, point->z);
           // ROS_WARN("[%d] (%.4f, %.4f, %.4f, %.4f)", i, point->x, point->y, point->z, point->doppler);
            // std::cout << "[" << i <<"]" << "(" << point->x << ", " << point->y << ", " << point->z << ")" << std::endl;
            // std::cout << "doppler: " << point->doppler << std::endl;
            if (fileOut)
            {
                fileOut << radar_num <<"," << elapsed_time << "," << frame_number << "," <<  i << "," << point->x << "," << point->y << "," << point->z << "," << point->doppler << "," << point->power << std::endl;
            }
        }
        std::cout << "sizeof(int): " << sizeof(int);
        std:: cout << " sizeof(float): " << sizeof(float);
        std:: cout << " sizeof(my_str): " << sizeof(my_str);
        std::cout << "my_data.size: " << my_data.size();

	}

    return 1;
}

void DataHandler::setOffset(std::vector<double> offsets) 
{
    offset_enable = true;
    this->offsets = offsets;
}

std::array<float, 3> DataHandler::offsetFeed(std::array<float, 3> initial)
{
    std::array<float, 3> final_value;
    final_value[0] = initial[0] * cos(offsets[3] * M_PI / 180.0) - initial[1] * sin(offsets[3] * M_PI / 180.0) + offsets[0];
    final_value[1] = initial[0] * sin(offsets[3] * M_PI / 180.0) + initial[1] * cos(offsets[3] * M_PI / 180.0) + offsets[1];
    final_value[2] = initial[2] + offsets[2];
    return final_value;
}

int8_t DataHandler::publish()
{
    pcl::PointXYZINormal pclPoint;

    if(radarPoint.points.size() != 0) {
        radarPoint.points.clear();
    }
    
    for(int i = 0; i < nPoints; i++) {
        // Point data 
        pclPoint.x = r_data[i].x; 
        pclPoint.y = r_data[i].y; 
        pclPoint.z = r_data[i].z;
        pclPoint.data[3] = 1.0f;
        pclPoint.intensity = r_data[i].power;
        pclPoint.normal_x = r_data[i].x * r_data[i].doppler; 
        pclPoint.normal_y = r_data[i].y * r_data[i].doppler; 
        pclPoint.normal_z = r_data[i].z * r_data[i].doppler;
        pclPoint.data_n[3] = 0.f;
        pclPoint.curvature = r_data[i].doppler;

        radarPoint.points.emplace_back(pclPoint);
    }

    radarPoint.width = nPoints;
    pcl_conversions::toPCL(ros::Time::now(), radarPoint.header.stamp);

    // Finally publish all the points from 4SN
    pub_points.publish(radarPoint);

    // send the data to the python publisher
    check();

    my_data.clear();

	return 1;
}


