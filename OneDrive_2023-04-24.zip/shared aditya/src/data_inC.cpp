#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include "retina4sn_viewer/data_handler.hpp"

#define PORT 8080

int main(int argc, char const *argv[]) {
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};
    const char* hello = "Hello from C++";

    ROS_WARN("Frame Counteiiiiooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo");
    
    // Create socket object
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }
    
    // Define server address
    serv_addr.sin_family = AF_INET; // IPv4
    serv_addr.sin_port = htons(PORT); // convert port nuber to network connunication standard of big-endian
    
    // Convert IPv4 and IPv6 addresses from text to binary form and store in sin_addr of the serv_addr struct
    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address/ Address not supported\n";
        return -1;
    }
    
    // Connect to server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }
    
    // Send data through socket
    send(sock , hello , strlen(hello) , 0 );
    std::cout << "Data sent from C++\n";

    // Receive data from server
    if ((valread = read(sock, buffer, 1024)) < 0) {
        std::cerr << "Read failed\n";
        return -1;
    }

    // Print received data
    std::cout << "Received message: " << buffer << std::endl;
    
    return 0;
}
