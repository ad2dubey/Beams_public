#ifndef DATA_HANDLER_H_
#define DATA_HANDLER_H_

#include <string>
#include <array>
#include <vector>
#include <fstream>
#include "ros/ros.h"
#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include "retina4sn_viewer/socket.hpp"

// Class
class DataHandler
{
    public : 
        DataHandler(ros::NodeHandle &nh);
        DataHandler(ros::NodeHandle &nh, const std::string & fileName);
        ~DataHandler();
        void init();
        void setFileOutput(const std::string & fileName);
        int8_t receive(Socket &sock , int radar_num);
        void setOffset(std::vector<double> offsets);
        std::array<float, 3> offsetFeed(std::array<float, 3> initial);
        int8_t publish();
        int check();//not original *****

    private :
        ros::NodeHandle handle;
        std::array<POINT_DATA, MAX_NUM_POINTS_PER_FRAME> r_data;

        struct my_str
        {
            float x;
            float y;
            float z;
            float power;
            float doppler;
            int32_t f_num;
            int32_t pt_num;
        };

        std::vector<my_str> my_data;
        //std::array<my_str, MAX_NUM_POINTS_PER_FRAME> my_data;
        

        std::ofstream fileOut;

        // Publisher
        ros::Publisher pub_points;

        // Messages to be published
        pcl::PointCloud<pcl::PointXYZINormal> radarPoint;

        ros::Time simulation_start;
        uint32_t frame_number, nPoints;

        bool offset_enable;
        std::vector<double> offsets;
};
#endif  // DATA_HANDLER_H_