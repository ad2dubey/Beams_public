#!/usr/bin/env python3
import socket
import struct

PORT = 8080

# Create socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # # Allow script to be re-ran after quitting (close TIME_WAIT)
s.bind(('127.0.0.1', PORT))

# Listen for incoming connections
s.listen()

print('Python program listening for connections')

while True:
    # Accept incoming connection
    conn, addr = s.accept()
    print('Connection established from', addr)
    
    # Receive data from connection
    #data = conn.recv(100016)
    #print('Data received in Python:', data)


    # Unpack the binary data into a list of structs

    vector_size= struct.unpack('Q', conn.recv(struct.calcsize('Q')))[0]

    vector_data =b''

    while len(vector_data)< vector_size * struct.calcsize('fffffii'):
        vector_data += conn.recv(vector_size * struct.calcsize('fffffii')- len(vector_data))


    received_vector=[]

    for i in range(vector_size):

        point = struct.unpack_from('fffffii', vector_data, i * struct.calcsize('fffffii'))

        received_vector.append(point)

    
    for point in received_vector:
        x,y,z,power,doppler, f_num, pt_num = point

        print(point)




    #num_structs = len(data) // struct.calcsize('fffffii')
    #arr = []
    #for i in range(num_structs):
        #struct_data = data[i*struct.calcsize('fffffii'):(i+1)*struct.calcsize('fffffii')]
        #x,y,z,power,doppler, f_num, pt_num = struct.unpack('fffffii', struct_data)
        #arr.append((x,y,z,power,doppler, f_num, pt_num))

    # Print received data
    
    #print(f'Received array:')
    #[print(x) for x in arr]
    print()
    print('********************************************************')
    print()

    
    # Process data in real time
    #processed_data = data.decode().upper()
    
    # Send processed data back to C++ program
    #conn.send(processed_data.encode())
    #print('Processed data sent from Python')
    
    # Close connection
    conn.close()
